# Handoff: [Título da Sessão]

## Contexto
- **Objetivo da sessão**: [descrever]
- **Estado inicial**: [descrever]
- **Documentos relevantes**: [links para specs, ADRs, etc.]

## Trabalho Realizado
- [x] [Item completado 1]
- [x] [Item completado 2]
- [ ] [Item iniciado mas não concluído] ([X]% pronto)

## Decisões Importantes
- [Decisão 1]: [Descrição e justificativa]
- [Decisão 2]: [Descrição e justificativa]
- [ADR criado]: [Link se aplicável]

## Estado Atual

### O que está funcionando
- [Item 1]
- [Item 2]

### O que está pendente
- [Item 1]
- [Item 2]

### Bloqueios
- [Bloqueio 1 se houver]
- [Bloqueio 2 se houver]

## Próximos Passos
- [ ] [Tarefa 1] (prioridade: [alta|média|baixa])
- [ ] [Tarefa 2] (prioridade: [alta|média|baixa])
- [ ] [Tarefa 3] (prioridade: [alta|média|baixa])

## Contexto para Próxima Sessão
[Informações críticas que a próxima pessoa ou IA precisa saber para continuar o trabalho efetivamente]

---

**Data**: [YYYY-MM-DD]
**Autor**: [Nome/Papel]
**Tempo de sessão**: [X horas]
