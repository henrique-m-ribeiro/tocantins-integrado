# Session Log: [YYYY-MM-DD]

## Sessão
- **Data/Hora**: [YYYY-MM-DD HH:MM - HH:MM]
- **Duração**: [X horas]
- **Papel**: [CEO | CTO | Dev]
- **Objetivo**: [Descrição breve]

## Atividades
- [HH:MM] [Atividade 1]
- [HH:MM] [Atividade 2]
- [HH:MM] [Atividade 3]

## Decisões
- [Decisão 1]
- [Decisão 2]

## Bloqueios/Impedimentos
- [Bloqueio 1 se houver]

## Próximo
- [Próxima ação]

## Notas
[Observações adicionais]

---

**Links úteis**:
- Handoff detalhado: [link se criado]
- Commits: [links]
- Issues: [links]
